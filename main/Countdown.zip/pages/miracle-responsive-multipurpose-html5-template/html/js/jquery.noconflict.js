sjq = jQuery.noConflict();
